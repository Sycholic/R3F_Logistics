/**
 * Constantes pour rendre les définitions des boîtes de dialogue plus lisible et maintenable
 */

#define R3F_LOG_TUTO_ID_dlg_tableau_START 485720

#define R3F_LOG_TUTO_IDD_dlg_tableau (R3F_LOG_TUTO_ID_dlg_tableau_START + 1)

#define R3F_LOG_TUTO_IDC_dlg_TAB_btn1 (R3F_LOG_TUTO_ID_dlg_tableau_START + 2)
#define R3F_LOG_TUTO_IDC_dlg_TAB_fond_btn1 (R3F_LOG_TUTO_ID_dlg_tableau_START + 3)
#define R3F_LOG_TUTO_IDC_dlg_TAB_btn2 (R3F_LOG_TUTO_ID_dlg_tableau_START + 4)
#define R3F_LOG_TUTO_IDC_dlg_TAB_fond_btn2 (R3F_LOG_TUTO_ID_dlg_tableau_START + 5)
#define R3F_LOG_TUTO_IDC_dlg_TAB_btn3 (R3F_LOG_TUTO_ID_dlg_tableau_START + 6)
#define R3F_LOG_TUTO_IDC_dlg_TAB_fond_btn3 (R3F_LOG_TUTO_ID_dlg_tableau_START + 7)
#define R3F_LOG_TUTO_IDC_dlg_TAB_btn4 (R3F_LOG_TUTO_ID_dlg_tableau_START + 8)
#define R3F_LOG_TUTO_IDC_dlg_TAB_fond_btn4 (R3F_LOG_TUTO_ID_dlg_tableau_START + 9)
#define R3F_LOG_TUTO_IDC_dlg_TAB_btn5 (R3F_LOG_TUTO_ID_dlg_tableau_START + 10)
#define R3F_LOG_TUTO_IDC_dlg_TAB_fond_btn5 (R3F_LOG_TUTO_ID_dlg_tableau_START + 11)
#define R3F_LOG_TUTO_IDC_dlg_TAB_btn6 (R3F_LOG_TUTO_ID_dlg_tableau_START + 12)
#define R3F_LOG_TUTO_IDC_dlg_TAB_fond_btn6 (R3F_LOG_TUTO_ID_dlg_tableau_START + 13)
#define R3F_LOG_TUTO_IDC_dlg_TAB_btn7 (R3F_LOG_TUTO_ID_dlg_tableau_START + 14)
#define R3F_LOG_TUTO_IDC_dlg_TAB_fond_btn7 (R3F_LOG_TUTO_ID_dlg_tableau_START + 15)
#define R3F_LOG_TUTO_IDC_dlg_TAB_btn8 (R3F_LOG_TUTO_ID_dlg_tableau_START + 16)
#define R3F_LOG_TUTO_IDC_dlg_TAB_fond_btn8 (R3F_LOG_TUTO_ID_dlg_tableau_START + 17)