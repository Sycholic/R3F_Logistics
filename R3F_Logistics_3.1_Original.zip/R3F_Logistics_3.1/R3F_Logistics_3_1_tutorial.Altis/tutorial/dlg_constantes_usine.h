/**
 * Constantes pour rendre les d�finitions des bo�tes de dialogue plus lisible et maintenable
 */

#define R3F_LOG_ID_usine_creation_START 65860

#define R3F_LOG_IDD_dlg_liste_objets (R3F_LOG_ID_usine_creation_START + 1)

#define R3F_LOG_IDC_dlg_LO_titre (R3F_LOG_ID_usine_creation_START + 2)
#define R3F_LOG_IDC_dlg_LO_credits_restants (R3F_LOG_ID_usine_creation_START + 3)
#define R3F_LOG_IDC_dlg_LO_liste_categories (R3F_LOG_ID_usine_creation_START + 4)
#define R3F_LOG_IDC_dlg_LO_liste_objets (R3F_LOG_ID_usine_creation_START + 5)
#define R3F_LOG_IDC_dlg_LO_btn_creer (R3F_LOG_ID_usine_creation_START + 6)
#define R3F_LOG_IDC_dlg_LO_btn_fermer (R3F_LOG_ID_usine_creation_START + 7)
#define R3F_LOG_IDC_dlg_LO_infos_titre (R3F_LOG_ID_usine_creation_START + 8)
#define R3F_LOG_IDC_dlg_LO_infos (R3F_LOG_ID_usine_creation_START + 9)