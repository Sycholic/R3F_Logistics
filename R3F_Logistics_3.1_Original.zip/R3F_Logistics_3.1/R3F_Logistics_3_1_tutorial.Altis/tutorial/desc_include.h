#include "cfgHints.h"
#include "dlg_tableau.h"

class CfgSounds
{
	sounds[] = {ContactInstructeur, ContactInstructeur2};
	class ContactInstructeur
	{
		name = "ContactInstructeur";
		sound[] = {"\a3\dubbing_f_bootcamp\boot_m02\15_Introduction\boot_m02_15_introduction_ADA_1", 1, 1};
		titles[] = {};
	};
	class ContactInstructeur2
	{
		name = "ContactInstructeur2";
		sound[] = {"a3\dubbing_f_bootcamp\boot_m02\15_Introduction\boot_m02_15_introduction_ADA_1", 1, 1};
		titles[] = {};
	};
};